<?php 
// error_reporting(E_ALL);
// ini_set("display_errors", 1);
include 'classes/Model/class.EventModel.php';
include 'classes/Controlador/Controller.php';
include 'classes/Controlador/class.EventController.php';
include 'classes/ObjectesDeNegoci/class.Event.php';
include 'classes/Vista/class.EventsView.php';

EventsView::show(EventModel::read());


