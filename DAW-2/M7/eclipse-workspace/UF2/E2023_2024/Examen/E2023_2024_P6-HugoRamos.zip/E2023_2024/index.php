<?php 
error_reporting(E_ALL);
ini_set("display_errors", 1);
include 'classes/Model/class.EventModel.php';
include 'classes/Controlador/Controller.php';
include 'classes/Controlador/class.EventController.php';
include 'classes/Controlador/class.FrontController.php';
include 'classes/Controlador/class.HomeController.php';
include 'classes/ObjectesDeNegoci/class.Event.php';
include 'classes/Vista/class.EventsView.php';

// EventsView::show(EventModel::read());
try {
    $cFront = new FrontController();
    $cFront->dispatch();
}catch (Exception $e) {
    
}