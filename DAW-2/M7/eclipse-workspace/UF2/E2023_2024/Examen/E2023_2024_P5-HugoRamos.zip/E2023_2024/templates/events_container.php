<div class="events-container">
	<span class="events__title">Upcoming events this month</span>
	<?php echo $events_list;?>
</div>
