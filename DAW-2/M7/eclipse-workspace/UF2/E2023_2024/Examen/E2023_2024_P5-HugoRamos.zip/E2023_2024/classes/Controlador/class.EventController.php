<?php
class EventController extends Controller {
    private Event $esdeveniment;
    
//     public function __construct(Event $param) {
//         parent::__construct();
//         $this->esdeveniment = $param;
//     }
    
    public static function get(Event $param) {
        
    }
    
    public static function post(Event $param) {
        
    }
    
//     public function get($param) {
        
//     }
    
//     public function post($param) {
        
//     }
}

?>