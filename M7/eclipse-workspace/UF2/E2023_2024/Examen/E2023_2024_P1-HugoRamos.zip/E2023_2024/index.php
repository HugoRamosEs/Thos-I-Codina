<?php 
error_reporting(E_ALL);
ini_set("display_errors", 1);
include 'classes/Model/class.EventModel.php';
include 'classes/Controlador/Controller.php';
include 'classes/Controlador/class.EventController.php';
include 'classes/ObjectesDeNegoci/class.Event.php';
include 'classes/Vista/class.EventsView.php';

$param1 = new Event("name", "from", "to", "tag");
$param2 = new Event("name", "from", "to", "tag");
$param3 = new Event("name", "from", "to", "tag");
$eventController = new EventController($param1, $param2, $param3);

EventsView::show(EventModel::read());


