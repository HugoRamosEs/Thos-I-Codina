<?php
class EventController extends Controller {
//     private Event $esdeveniment;
       private array $esdeveniment;
    
//     public function __construct(Event $param) {
//         parent::__construct();
//         $this->esdeveniment = $param;
//     }

    public function __construct(Event ...$param) {
           parent::__construct();
           $this->esdeveniment = $param;
    }
    
    public function get($param) {
        
    }
    
    public function post($param) {
        
    }
}

?>