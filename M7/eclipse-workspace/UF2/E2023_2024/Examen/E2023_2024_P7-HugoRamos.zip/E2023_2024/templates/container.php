<div class="main-container-wrapper">
	<main>
		<?php 
		include 'calendar_container.php';
        include 'events_container.php';
        ?>
	</main>	
</div>
