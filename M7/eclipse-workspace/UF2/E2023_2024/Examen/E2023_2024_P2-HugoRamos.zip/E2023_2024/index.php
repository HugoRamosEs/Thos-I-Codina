<?php 
error_reporting(E_ALL);
ini_set("display_errors", 1);
include 'classes/Model/class.EventModel.php';
include 'classes/Controlador/Controller.php';
include 'classes/Controlador/class.EventController.php';
include 'classes/ObjectesDeNegoci/class.Event.php';
include 'classes/Vista/class.EventsView.php';

/**
 * PREGUNTA 2
 * Esta pregunta no se puede realizar, debido a que PHP no admite sobreacarga de funciones, como otros lenguajes de programacion. En
 * resumidas cuentas, no puede haber una funcion con el mismo nombre, todo y que se le pasen diferentes parámetros.
 */

EventsView::show(EventModel::read());


