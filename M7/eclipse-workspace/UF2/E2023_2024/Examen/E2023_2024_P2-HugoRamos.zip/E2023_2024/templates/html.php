<!DOCTYPE html>
<html lang="ca">
	<?php include 'head.php';?>
	<?php include 'body.php';?>
</html>>